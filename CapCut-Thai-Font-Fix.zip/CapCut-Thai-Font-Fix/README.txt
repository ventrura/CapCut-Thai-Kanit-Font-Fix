﻿แก้เมนูภาษาไทยใน CapCut PC ตัวเล็ก
==================================
1. ดับเบิลคลิก Fix-CapCut-Thai.bat
   (ถ้า CapCut เปิดอยู่ โปรแกรมจะถามก่อนปิดให้ ตอบ Y)
2. ขึ้นคำว่า "Fixed!" แล้ว เปิด CapCut ใหม่ได้เลย

- หลัง CapCut อัปเดต ถ้าตัวหนังสือกลับมาเล็กอีก ให้รัน Fix-CapCut-Thai.bat ซ้ำ
- ถ้าอยากคืนค่าฟอนต์เดิม ให้ดับเบิลคลิก Restore-Original.bat
- ถ้า Windows ขึ้นหน้าต่าง "Windows protected your PC" ให้กด More info แล้วกด Run anyway
- ฟอนต์ Kanit ใช้สัญญาอนุญาต SIL Open Font License (ดู fonts/OFL-Kanit.txt)
